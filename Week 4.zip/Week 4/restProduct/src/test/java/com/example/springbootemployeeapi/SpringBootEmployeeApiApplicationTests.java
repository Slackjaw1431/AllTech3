package com.example.springbootemployeeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmployeeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
