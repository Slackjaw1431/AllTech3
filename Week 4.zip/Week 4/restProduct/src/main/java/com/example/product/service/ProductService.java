package com.example.product.service;

import java.util.List;
import java.util.Optional;

import com.example.product.entity.Product;

public interface ProductService {
	
	Product saveProduct(Product product);
	List<Product> fetchProducts();
	void delete(Product product);
	Product update(Product product);
	Optional<Product> get(Long id);	
}
