package com.example.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.product.entity.Product;
import com.example.product.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository pr;

	@Override
	public Product saveProduct(Product p) {
		return pr.save(p);
	}

	@Override
	public List<Product> fetchProducts() {
		return (List<Product>)pr.findAll();
	}

	@Override
	public void delete(Product p) {
		pr.delete(p);
	}

	@Override
	public Product update(Product p) {
		return pr.save(p);
	}

	@Override
	public Optional<Product> get(Long id) {
		if(pr.existsById(id)) {
			return pr.findById(id);
		}
		return Optional.empty();
	}
	
	

}
