package com.example.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.entity.Product;
import com.example.product.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping("")
	public String hello() {
		return "form";
	}

	@PostMapping("/products")
	public Product addProduct(@Validated @RequestBody Product product) {
		return productService.saveProduct(product);
	}

	@GetMapping("/products")
	public List<Product> getAllProducts() {
		return productService.fetchProducts();
	}
	
	@GetMapping("/products/{id}")
	public Optional<Product> get(@RequestParam(value = "id") Long id) {
		return productService.get(id);
	}

	@PutMapping("/products")
	public Product edit(@RequestBody Product product) {
		return productService.update(product);
	}

	@DeleteMapping("/products")
	public String delete(@RequestParam(value = "id") Long id) {
		Optional<Product> e = productService.get(id);
		productService.delete(e.get());
		return "Product " + id + " deleted";
	}

}
