package com.customer.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.entity.Customer;
import com.customer.repository.CustomerRepository;
import com.customer.request.CreateCustomerRequest;
import com.customer.response.CustomerResponse;

@Service
public class CustomerService {

	Logger logger = LoggerFactory.getLogger(CustomerService.class);

	@Autowired
	CustomerRepository customerRepository;

	public CustomerResponse createCustomer(CreateCustomerRequest createCustomerRequest) {

		Customer customer = new Customer();
		customer.setId(createCustomerRequest.getCustomerId());
		customer.setFirstName(createCustomerRequest.getFirstName());
		customer.setLastName(createCustomerRequest.getLastName());
		customer.setCustomerAddress(createCustomerRequest.getCustomerAddress());

		customerRepository.save(customer);

		return new CustomerResponse(customer);

	}

	public CustomerResponse getById(long id) {

		Customer customer = customerRepository.findById(id).get();

		return new CustomerResponse(customer);
	}

}
