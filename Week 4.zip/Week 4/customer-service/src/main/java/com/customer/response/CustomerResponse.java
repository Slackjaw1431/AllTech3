package com.customer.response;

import com.customer.entity.Customer;

public class CustomerResponse {

	private Long customerId;

	private String firstName;
	private String lastName;
	private String customerAddress;

	public CustomerResponse(Customer c) {
		this.customerId = c.getId();
		this.firstName = c.getFirstName();
		this.lastName = c.getLastName();
		this.customerAddress = c.getCustomerAddress();
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

}
