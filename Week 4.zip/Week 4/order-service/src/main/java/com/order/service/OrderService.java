package com.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.order.entity.Order;
import com.order.feignclients.CustomerFeignClient;
import com.order.repository.OrderRepository;
import com.order.request.CreateOrderRequest;
import com.order.response.CustomerResponse;
import com.order.response.OrderResponse;

import reactor.core.publisher.Mono;

@Service
public class OrderService {

	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	WebClient webClient;
	
//	@Autowired
//	CustomerFeignClient customerFeignClient;

	public OrderResponse createOrder(CreateOrderRequest createOrderRequest) {

		Order order = new Order();
		order.setOrderDate(createOrderRequest.getOrderDate());
		order.setShipToAddress(createOrderRequest.getShipToAddress());
		order.setCustomerId(createOrderRequest.getCustomerId());
		order = orderRepository.save(order);
		
		OrderResponse orderResponse = new OrderResponse(order);
		
		orderResponse.setCustomerResponse(getCustomerById(order.getCustomerId()));

		return orderResponse;
	}
	
	public OrderResponse getById (Long id) {
		Order order = orderRepository.findById(id).get();
		OrderResponse orderResponse = new OrderResponse(order);
		
		orderResponse.setCustomerResponse(getCustomerById(order.getCustomerId()));
//		orderResponse.setCustomerResponse(customerFeignClient.getById(order.getCustomerId()));

		return orderResponse;
	}
	
	public CustomerResponse getCustomerById (Long customerId) {
		Mono<CustomerResponse> customerResponse = 
				webClient.get().uri("/getById/" + customerId)
		.retrieve().bodyToMono(CustomerResponse.class);				
		return customerResponse.block();
	}
	
}
