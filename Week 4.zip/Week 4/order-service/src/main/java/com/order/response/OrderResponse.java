package com.order.response;

import java.sql.Date;

import com.order.entity.Order;

public class OrderResponse {

	private Long orderId;

	private Date orderDate;

	private String shipToAddress;
	private Long customerId;

	private CustomerResponse customerResponse;

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getShipToAddress() {
		return shipToAddress;
	}

	public void setShipToAddress(String shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	public OrderResponse(Order o) {
		this.orderId = o.getId();
		this.orderDate = o.getOrderDate();
		this.shipToAddress = o.getShipToAddress();
		this.customerId = o.getCustomerId();
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date date) {
		this.orderDate = date;
	}

	public CustomerResponse getCustomerResponse() {
		return customerResponse;
	}

	public void setCustomerResponse(CustomerResponse customerResponse) {
		this.customerResponse = customerResponse;
	}

}
