package com.order.feignclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.order.response.CustomerResponse;

@FeignClient(url = "${customer.service.url}", value = "customer-feign-client", path = "")
public interface CustomerFeignClient {

	@GetMapping("/getById/{id}")
	public CustomerResponse getById(@PathVariable long id);

}
