package com.order.app;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
@ComponentScan({"com.order.controller", "com.order.service"})
@EntityScan("com.order.entity")
@EnableJpaRepositories("com.order.repository")
@EnableEurekaClient
//@EnableFeignClients("com.order.feignclients")
public class OrderServiceApplication {
	
	@Value("${customer.service.url}")
	private String customerServiceUrl;

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceApplication.class, args);
	}
	
	@Bean
	public WebClient webClient () {
		WebClient webClient = WebClient.builder()
				.baseUrl(customerServiceUrl).build();
		
		return webClient;
	}

}
