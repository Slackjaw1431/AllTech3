package com.order.response;

public class CustomerResponse {

	private Long customerId;

	private String firstName;
	private String lastName;

	private String customerAddress;

//	private OrderResponse orderResponse;

	public String getFirstName() {
		return firstName;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

//	public OrderResponse getOrderResponse() {
//		return orderResponse;
//	}
//
//	public void setOrderResponse(OrderResponse orderResponse) {
//		this.orderResponse = orderResponse;
//	}

}
