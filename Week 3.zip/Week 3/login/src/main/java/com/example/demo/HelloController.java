package com.example.demo;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelloController {
	
	@GetMapping("/hello")
	public String message() {
		return "form";
	}
	
	@GetMapping("/greeting")
	public String greeting(Map<String, Object> model) {
		model.put("name","fname lname");
		return "greeting";
	}

}
