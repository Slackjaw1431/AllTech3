package com.example.demo;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {
	
	static String user = "Amit";
	static String passw = "password";
	
	@PostMapping("/login")
	public String response(String name, String pass, Map<String, Object> model) {
		
		if(name.equals(user) && pass.equals(passw)) {
			model.put("name",user);
			model.put("pass", passw);
			return "success";		
		}
		else {
			return "error";			
		}
	}

}
