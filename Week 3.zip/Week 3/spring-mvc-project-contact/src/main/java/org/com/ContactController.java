package org.com;

import java.util.List;
import java.util.Map;

import org.model.Contact;
import org.model.ContactDAO;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ContactController {

	static String user = "Amit";
	static String passw = "password";

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String response(String name, String pass, Map<String, Object> model) {

		if (name.equals(user) && pass.equals(passw)) {
			model.put("name", user);
			model.put("pass", passw);
			return "contact_form";
		} else {
			return "error";
		}
	}

	@RequestMapping(value = "/contactForm", method = RequestMethod.POST)
	public ModelAndView insert(@RequestParam("id") int id, @RequestParam("fullAddress") String fullAddress,
			@RequestParam("phoneNo") int phoneNo, ModelMap model) {
		ModelAndView view = new ModelAndView("welcome");
		Contact contact = new Contact(id, fullAddress, phoneNo);

//		contact.setId(id);
		contact.setFullAddress(fullAddress);
		contact.setPhoneNo(phoneNo);

		ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		ContactDAO contactDAO = (ContactDAO) ctx.getBean("contactDAO");
		contactDAO.insert(contact);

		List<Contact> list = contactDAO.findAll();

		model.addAttribute("listContacts", list);

		return view;
	}

	@RequestMapping(value = "/findContact", method = RequestMethod.POST)
	public ModelAndView find(@RequestParam("id") int id, ModelMap model) {
		ModelAndView view = new ModelAndView("welcome");

		ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		ContactDAO contactDAO = (ContactDAO) ctx.getBean("contactDAO");

		Contact c = contactDAO.findById(id);

		model.addAttribute("contact", c);

		return view;
	}

	@RequestMapping(value = "/listContacts", method = RequestMethod.GET)
	public ModelAndView ListContacts(ModelMap model) {
		ModelAndView view = new ModelAndView("welcome");
		ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		ContactDAO contactDAO = (ContactDAO) ctx.getBean("contactDAO");

		List<Contact> list = contactDAO.findAll();

		model.addAttribute("listContacts", list);

		return view;
	}

	@RequestMapping("/remove/{id}")
	public ModelAndView removeContact(@PathVariable("id") int id, ModelMap model) {
		ModelAndView view = new ModelAndView("welcome");
		ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		ContactDAO contactDAO = (ContactDAO) ctx.getBean("contactDAO");
		contactDAO.delete(id);

		List<Contact> list = contactDAO.findAll();

		model.addAttribute("listContacts", list);

		return view;
	}

	@RequestMapping("/edit/{id}")
	public ModelAndView editContact(@PathVariable("id") int id, Model model) {
		ModelAndView view = new ModelAndView("update");
		ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		ContactDAO contactDAO = (ContactDAO) ctx.getBean("contactDAO");

		Contact c = contactDAO.findById(id);

		model.addAttribute("contact", c);
		model.addAttribute("id", c.getId());
		model.addAttribute("fullAddress", c.getFullAddress());
		model.addAttribute("phoneNo", c.getPhoneNo());

		return view;
	}

	@RequestMapping(value = "/edit/update", method = RequestMethod.POST)
	public ModelAndView updateContact(@RequestParam("id") int id, @RequestParam("fullAddress") String fullAddress,
			@RequestParam("phoneNo") int phoneNo, Model model) {
		ModelAndView view = new ModelAndView("welcome");
		ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		ContactDAO contactDAO = (ContactDAO) ctx.getBean("contactDAO");

		Contact c = contactDAO.findById(id);

		c.setFullAddress(fullAddress);
		c.setPhoneNo(phoneNo);

		contactDAO.update(c);

		List<Contact> list = contactDAO.findAll();

		model.addAttribute("listContacts", list);

		return view;
	}

}
