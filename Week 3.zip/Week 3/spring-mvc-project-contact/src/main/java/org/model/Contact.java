package org.model;

public class Contact {
	private int id;
	private String fullAddress;
	private int phoneNo;

	public Contact(int id, String fullAddress, int phoneNo) {
		this.id = id;
		this.fullAddress = fullAddress;
		this.phoneNo = phoneNo;
	}

	public Contact() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullAddress() {
		return fullAddress;
	}

	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}

	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Contact [id=" + id + ", fullAddress=" + fullAddress + ", phoneNo=" + phoneNo + "]";
	}

}
