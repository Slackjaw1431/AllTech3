package org.model;

import java.util.List;
import java.util.Scanner;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class ContactDAOImpl implements ContactDAO {

	private JdbcTemplate jdbcTemplate;
	Scanner scan = new Scanner(System.in);

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public ContactDAOImpl() {
	}

	@Override
	public void insert(Contact contact) {
		String sql = "INSERT into contacts " + "(ID, fullAddress, phoneNo) VALUES (?,?,?)";

		jdbcTemplate.update(sql, new Object[] { contact.getId(), contact.getFullAddress(), contact.getPhoneNo() });
	}

	@Override
	public Contact findById(int id) {
		String sql = "SELECT * FROM contacts WHERE ID = ?";

		try {
			Contact contact = (Contact) jdbcTemplate.queryForObject(sql, new Object[] { id }, new ContactMapper());
			return contact;
		} catch (Exception e) {
			System.out.println("No Contact found");
		}
		return null;
	}

	@Override
	public void delete(int id) {
		try {
			String sql = "DELETE FROM contacts WHERE ID = ?";
			Object[] args = new Object[] { id };

			jdbcTemplate.update(sql, args);
		} catch (Exception e) {
			System.out.println("No Contact found");
		}

	}

	@Override
	public void update(Contact contact) {

		String sql = "UPDATE contacts SET fullAddress = ?, phoneNo = ? WHERE id = ?";

		try {
			jdbcTemplate.update(sql, new Object[] { contact.getFullAddress(), contact.getPhoneNo(), contact.getId() });
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<Contact> findAll() {
		String sql = "SELECT * FROM contacts";

		List<Contact> contacts = jdbcTemplate.query(sql, new ContactMapper());

		for (Contact c : contacts) {
			System.out.println(c);
		}
		return contacts;
	}

}
