package org.model;

import java.util.List;

public interface ContactDAO {
	
	public void insert(Contact contact);
	public Contact findById(int id);
	public void delete(int id);
	public void update(Contact contact);
	public List<Contact> findAll();

}
