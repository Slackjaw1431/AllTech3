package org.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ContactMapper implements RowMapper<Contact> {
	public Contact mapRow(ResultSet resultSet, int i) throws SQLException {
		Contact contact = new Contact();
		contact.setId(resultSet.getInt("ID"));
		contact.setFullAddress(resultSet.getString("fullAddress"));
		contact.setPhoneNo(resultSet.getInt("phoneNo"));
		return contact;
	}
	

}
