import java.util.Scanner;

public class Order {

	int orderId;
	String orderName;
	String category;
	double price;
	double tax;

	public Order() {

	}

	public Order(int orderId, String orderName,
			String category, double price, double tax) {

		if (!category.equalsIgnoreCase("Shipping")
				&& !category.equalsIgnoreCase("Air")
				&& !category.equalsIgnoreCase("Road")) {
			System.out.println(
					"Incorrect category. Must be Shipping, Air, or Road");
		} else if (category.equalsIgnoreCase("Shipping")) {
			this.orderId = orderId;
			this.orderName = orderName;
			this.category = category;
			this.price = price;
			this.tax = 15;
		} else if (category.equalsIgnoreCase("Air")) {
			this.orderId = orderId;
			this.orderName = orderName;
			this.category = category;
			this.price = price;
			this.tax = 25;
		} else if (category.equalsIgnoreCase("Road")) {
			this.orderId = orderId;
			this.orderName = orderName;
			this.category = category;
			this.price = price;
			this.tax = 8;
		}
	}

	public void dispOrder() {
		this.price = price + tax;
		System.out.println(toString());
	}

	public void acceptData() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter order ID");
		this.orderId = scan.nextInt();
		System.out.println("Enter order name");
		this.orderName = scan.next();
		System.out.println("Enter order price");
		this.price = scan.nextDouble();
		System.out.println("Enter order category");
		this.category = scan.next();
		

		if (!category.equalsIgnoreCase("Shipping")
				&& !category.equalsIgnoreCase("Air")
				&& !category.equalsIgnoreCase("Road")) {
			System.out.println(
					"Incorrect category. Must be Shipping, Air, or Road");
			this.orderId = 0;
			this.orderName = null;
			this.category = null;
			this.price = 0;
			this.tax = 0;
		}
		else {
			this.tax = calcTax(category);			
		}
		
	}

	public double calcTax(String category) {

		double tax = 0;
		
		if (category.equalsIgnoreCase("Shipping")) {
			tax = 15;
		} else if (category.equalsIgnoreCase("Air")) {
			tax = 25;
		} else if (category.equalsIgnoreCase("Road")) {
			tax = 8;
		}
		return tax;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderName="
				+ orderName + ", category=" + category
				+ ", price=" + price + ", tax=" + tax + "]";
	}

}
