
public class TestOrder {

	public static void main(String[] args) {

		Order order1 = new Order();
		Order order2 = new Order();

		order1.acceptData();
		order1.dispOrder();
		System.out.println();
		order2.acceptData();
		order2.dispOrder();

	}

}
